import 'package:flutter/material.dart';
import 'package:language_app/app/app.dart';
import 'package:language_app/app/global/app_global.dart';

Future<void> main() async {
  await Global.init();
  runApp(App());
}

