




import 'package:flutter/material.dart';
import 'package:language_app/app/utils/colors/app_colors.dart';


class AppTheme {
  static ThemeData get light => ThemeData(
        useMaterial3: true,
        colorScheme: const ColorScheme.light(
          primary: Color(0xFF1E88E5), // Ko‘k
          secondary: Color(0xFF43A047), // Yashil
          error: Color(0xFFD32F2F), // Qizil
        ),
        extensions: const [
          CustomColors.light, // Light Mode uchun CustomColors
        ],
      );

  static ThemeData get dark => ThemeData(
        useMaterial3: true,
        colorScheme: const ColorScheme.dark(
          primary: Color(0xFF1E88E5), 
          secondary: Color(0xFF43A047),
          error: Color(0xFFD32F2F),
        ),
        extensions: const [
          CustomColors.dark, // Dark Mode uchun CustomColors
        ],
      );
}