





import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:language_app/app/bloc/app_bloc.dart';
import 'package:language_app/app/pages/application/application_page.dart';
import 'package:language_app/app/pages/application/bloc/application_bloc.dart';
import 'package:language_app/app/routes/name.dart';


class AppPages {
    static List<PageEntity> routes(){
        return [
            PageEntity(
                route: AppRoutes.INITIAL,
                page:  ApplicationPage(),
                bloc: BlocProvider(create: (_)=> ApplicationBloc())
            ),
            // PageEntity(
            //     route: '',
            //     page: ApplicationPage(),
            //     bloc: BlocProvider(create: (_)=> ThemeCubit())
            // ),
        ];
    }


    static List<dynamic> allBlocProviders(BuildContext context) {
        List<dynamic> blocProviders = <dynamic> [];
        for (var bloc in routes()) {
            if (bloc.bloc !=null) {
                blocProviders.add(bloc.bloc); 
            }
        }
        blocProviders.add(
            BlocProvider(create: (_)=> AppBloc())
        ); 
        return blocProviders;

    }

    static MaterialPageRoute GenerateRouteSettings (RouteSettings   settings) {
        if (settings.name != null) {
            var result = routes().where((element) => element.route == settings.name);
            if (result.isNotEmpty) {
                return MaterialPageRoute(builder: (_) => result.first.page!, settings: settings);
            }
        }
        return MaterialPageRoute(builder: (_) => ApplicationPage(), settings: settings);
    }
}



class PageEntity {
    String? route;
    Widget? page;
    dynamic bloc;

    PageEntity({ required this.route, required  this.page, this.bloc});
}