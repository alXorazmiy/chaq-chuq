


class AppRoutes {
    static const INITIAL = "/";
}