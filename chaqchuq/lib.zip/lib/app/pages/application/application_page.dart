
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import 'package:language_app/app/pages/application/bloc/application_bloc.dart';
import 'package:language_app/app/pages/application/bloc/application_event.dart';
import 'package:language_app/app/pages/application/bloc/application_state.dart';
import 'package:language_app/app/pages/application/widgets/bottomNavigationBar.dart';
import 'package:language_app/app/pages/application/widgets/widgets.dart';

import 'package:language_app/app/utils/colors/app_colors.dart';

class ApplicationPage extends StatefulWidget {
  const ApplicationPage({super.key});

  @override
  State<ApplicationPage> createState() => _ApplicationPageState();
}

class _ApplicationPageState extends State<ApplicationPage> {
    @override
    Widget build(BuildContext context) {
        final customColors = Theme.of(context).extension<CustomColors>()!;
        return BlocBuilder<ApplicationBloc, ApplicationState>(
            builder: (context, state) {
                return Scaffold(
                    backgroundColor: customColors.backgroundColor,
                    body: Center(
                        child: buildPage(state.index),
                    ),
                    
                
                    bottomNavigationBar: Container(
                        width: 375.w,
                        height: 58.h,
                        child: BottomNavigationBar(
                            currentIndex: state.index,
                            elevation: 0,
                            type: BottomNavigationBarType.fixed,
                            backgroundColor: customColors.backgroundColor,
                            showSelectedLabels: false,
                            showUnselectedLabels: false,
                            onTap: (value) {
                                context.read<ApplicationBloc>().add(TriggerApplicationEvent(value));
                            },
                            items: bottomTabs,
                        ),
                    ),
                );
            },
        );
    }
}
