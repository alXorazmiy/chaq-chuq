



import 'package:flutter/material.dart';
import 'package:language_app/app/pages/home/home_page.dart';
import 'package:language_app/app/pages/person/profile_page.dart';
import 'package:language_app/app/pages/search/search_page.dart';

Widget buildPage(int index) {
    List<Widget> _widget = [
        HomePage(),
        SearchPage(),
        ProfilePage(),
    ];
    return _widget[index];
}