
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

var bottomTabs = [
    BottomNavigationBarItem(
        label: "Home",
        icon: SizedBox(
            width: 15.w,
            height: 15.h,
            child: Icon(Icons.home, color: Colors.blue),
        ),
    ),
    BottomNavigationBarItem(
        label: "Search",
        icon: SizedBox(
            width: 15.w,
            height: 15.h,
            child: Icon(Icons.search,color: Colors.blue),
        ),
    ),
    BottomNavigationBarItem(
        label: "Profile",
        icon: SizedBox(
            width: 15.w,
            height: 15.h,
            child: Icon(Icons.person,color: Colors.blue),
        ),
    ),
]  ;