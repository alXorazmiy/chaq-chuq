


import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:language_app/app/bloc/app_bloc.dart';
import 'package:language_app/app/bloc/app_event.dart';
import 'package:language_app/app/utils/colors/app_colors.dart';

class ProfilePage extends StatefulWidget {
  const ProfilePage({super.key});

  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  @override
  Widget build(BuildContext context) {
        final customColors = Theme.of(context).extension<CustomColors>()!;

    return Scaffold(
                backgroundColor: customColors.backgroundColor,
                body: Center(
                    child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                        Text(
                        'Rejimni almashtirish uchun tugmani bosing',
                        style: TextStyle(color: customColors.textColor),
                        ),
                        const SizedBox(height: 20),
                        ElevatedButton(
                        onPressed: () {
                            context
                                .read<AppBloc>()
                                .add(ChangeTheme(themeMode: "light"));
                        },
                        child: Text("day".tr()),
                        ),
                        ElevatedButton(
                        onPressed: () {
                            context.read<AppBloc>().add(ChangeTheme(themeMode: "dark"));
                        },
                        child: Text('night'.tr()),
                        ),
                        ElevatedButton(
                        onPressed: () {
                            context
                                .read<AppBloc>()
                                .add(ChangeTheme(themeMode: "system"));
                        },
                        child: Text('system'.tr()),
                        ),
                        Text(
                        'change_language'.tr(),
                        style: TextStyle(color: customColors.textColor),
                        ),
                        const SizedBox(height: 20),
                        ElevatedButton(
                        onPressed: () {
                            context.read<AppBloc>().add(ChangeLanguage(
                                newLocale: Locale('uz', 'UZ'), context: context));
                            context.setLocale(Locale('uz', 'UZ'));
                        },
                        child: const Text('uzbek tili'),
                        ),
                        ElevatedButton(
                        onPressed: () {
                            context.read<AppBloc>().add(ChangeLanguage(
                                newLocale: Locale('ru', 'RU'), context: context));
                            context.setLocale(Locale('ru', 'RU'));
                        },
                        child: const Text('Rus tili'),
                        ),
                        ElevatedButton(
                        onPressed: () {
                            context.read<AppBloc>().add(ChangeLanguage(
                                newLocale: Locale('en', 'US'), context: context));
                            context.setLocale(Locale('en', 'US'));
                        },
                        child: const Text('Ingliz tili'),
                        ),
                    ],
                    ),
                ),
                
                );
  }
}