


class AppConstants {
    static  const String DEVICE_THEME_MODE = "device_theme_mode";
    static  const String DEVICE_LANGUAGE = "device_language";
}