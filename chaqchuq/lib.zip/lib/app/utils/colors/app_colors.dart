import 'package:flutter/material.dart';

@immutable
class CustomColors extends ThemeExtension<CustomColors> {
    final Color backgroundColor;
    final Color textColor;

    const CustomColors({
        required this.backgroundColor,
        required this.textColor,
    });


    static const CustomColors light = CustomColors(
        backgroundColor: Color(0xFFFFFFFF),
        textColor: Color(0xFF000000), 
    );

    static const CustomColors dark = CustomColors(
        backgroundColor: Color(0xFF121212), 
        textColor: Color(0xFFFFFFFF),
    );

    @override
    CustomColors copyWith({Color? backgroundColor, Color? textColor}) {
        return CustomColors(
        backgroundColor: backgroundColor ?? this.backgroundColor,
        textColor: textColor ?? this.textColor,
        );
    }

    @override
    ThemeExtension<CustomColors> lerp(ThemeExtension<CustomColors>? other, double t) {
        if (other is! CustomColors) return this;
        return CustomColors(
            backgroundColor: Color.lerp(backgroundColor, other.backgroundColor, t)!,
            textColor: Color.lerp(textColor, other.textColor, t)!,
      );
    } 
}
